function returnTime()
{
  var dt = new Date();
      return (dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds());

}